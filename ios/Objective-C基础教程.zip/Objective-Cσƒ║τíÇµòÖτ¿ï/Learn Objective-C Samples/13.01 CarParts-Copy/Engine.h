#import <Cocoa/Cocoa.h>

@interface Engine : NSObject <NSCopying>
@end // Engine

