#import <Foundation/Foundation.h>

@interface ITunesFinder : NSObject
@end // ITunesFinder
