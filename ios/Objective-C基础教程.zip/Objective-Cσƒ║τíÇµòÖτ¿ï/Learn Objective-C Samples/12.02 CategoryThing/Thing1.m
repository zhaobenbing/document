#import "CategoryThing.h"

@implementation CategoryThing (Thing1)

- (void) setThing1: (int) t1
{
    thing1 = t1;
} // setThing1


- (int) thing1
{
    return (thing1);
} // thing1

@end // CategoryThing
