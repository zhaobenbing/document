//
//  main.m
//  CaseTool
//
//  Created by markd on 8/6/08.
//  Copyright Length-O-Words.com 2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
